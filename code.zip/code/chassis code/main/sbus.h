#ifndef _SBUS_H_
#define _SBUS_H_

extern int rcsig[25];
void InitSbus();
void GetSignal();
void PrintSignal();

#endif
