#ifndef _APP_H_
#define _APP_H_

//void DelayMs(uint16 ms);
void TaskRun(void);
extern double ref1, ref2, ref3, ref4;
extern unsigned long t,T;

#endif
